import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { CalendarDays, MapPin } from "lucide-react";

const Experience = () => {
  const experiences = [
    {
      title: "Senior Frontend Developer",
      company: "Tech Company Inc.",
      location: "San Francisco, CA",
      period: "2022 - Present",
      description: [
        "Led development of responsive web applications using React and TypeScript",
        "Implemented design systems that improved development efficiency by 40%",
        "Mentored junior developers and conducted code reviews",
        "Collaborated with UX designers to create pixel-perfect interfaces"
      ],
      technologies: ["React", "TypeScript", "Next.js", "TailwindCSS", "AWS"]
    },
    {
      title: "Full Stack Developer",
      company: "Startup Solutions",
      location: "Remote",
      period: "2020 - 2022",
      description: [
        "Built and maintained multiple client projects from conception to deployment",
        "Developed RESTful APIs and integrated third-party services",
        "Optimized application performance resulting in 50% faster load times",
        "Worked directly with clients to gather requirements and provide technical guidance"
      ],
      technologies: ["JavaScript", "Node.js", "MongoDB", "React", "Express"]
    },
    {
      title: "Frontend Developer",
      company: "Digital Agency Co.",
      location: "New York, NY",
      period: "2019 - 2020",
      description: [
        "Created responsive websites and landing pages for various clients",
        "Collaborated with designers to implement pixel-perfect designs",
        "Improved website accessibility and SEO performance",
        "Maintained and updated existing client websites"
      ],
      technologies: ["HTML5", "CSS3", "JavaScript", "WordPress", "PHP"]
    }
  ];

  return (
    <section id="experience" className="py-20 px-4 sm:px-6 lg:px-8">
      <div className="max-w-4xl mx-auto">
        {/* Section Header */}
        <div className="text-center mb-16">
          <h2 className="text-4xl sm:text-5xl font-bold mb-6">
            Work <span className="text-gradient">Experience</span>
          </h2>
          <p className="text-xl text-muted-foreground">
            {/* TODO: Add your experience overview */}
            My professional journey in software development, working with amazing teams 
            to build innovative solutions and deliver exceptional user experiences.
          </p>
        </div>

        {/* Timeline */}
        <div className="relative">
          {/* Timeline Line */}
          <div className="absolute left-8 top-0 bottom-0 w-px cosmic-gradient"></div>

          {/* Experience Items */}
          <div className="space-y-12">
            {experiences.map((exp, index) => (
              <div key={index} className="relative flex items-start">
                {/* Timeline Dot */}
                <div className="absolute left-6 w-4 h-4 cosmic-gradient rounded-full border-4 border-background"></div>
                
                {/* Content */}
                <div className="ml-20 w-full">
                  <Card className="glass-card hover:shadow-cosmic smooth-transition">
                    <CardHeader>
                      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2">
                        <div>
                          <CardTitle className="text-xl">{exp.title}</CardTitle>
                          <CardDescription className="text-lg font-medium text-cosmic-primary">
                            {exp.company}
                          </CardDescription>
                        </div>
                        <div className="flex flex-col sm:items-end text-sm text-muted-foreground">
                          <div className="flex items-center gap-1">
                            <CalendarDays className="h-4 w-4" />
                            {exp.period}
                          </div>
                          <div className="flex items-center gap-1 mt-1">
                            <MapPin className="h-4 w-4" />
                            {exp.location}
                          </div>
                        </div>
                      </div>
                    </CardHeader>
                    
                    <CardContent>
                      <ul className="space-y-2 mb-6">
                        {exp.description.map((item, itemIndex) => (
                          <li key={itemIndex} className="flex items-start">
                            <span className="text-cosmic-primary mr-2">•</span>
                            <span className="text-muted-foreground">{item}</span>
                          </li>
                        ))}
                      </ul>
                      
                      <div className="flex flex-wrap gap-2">
                        {exp.technologies.map((tech) => (
                          <Badge key={tech} variant="outline" className="text-sm">
                            {tech}
                          </Badge>
                        ))}
                      </div>
                    </CardContent>
                  </Card>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default Experience;