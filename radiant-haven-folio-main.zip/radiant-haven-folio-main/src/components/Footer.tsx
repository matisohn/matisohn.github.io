import { Github, Linkedin, Mail, Heart } from "lucide-react";

const Footer = () => {
  const currentYear = new Date().getFullYear();
  
  const socialLinks = [
    {
      icon: Github,
      label: "GitHub",
      url: "https://github.com/yourusername"
    },
    {
      icon: Linkedin,
      label: "LinkedIn", 
      url: "https://linkedin.com/in/yourprofile"
    },
    {
      icon: Mail,
      label: "Email",
      url: "mailto:your.email@example.com"
    }
  ];

  return (
    <footer className="bg-muted/50 py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto">
        <div className="flex flex-col items-center space-y-6">
          {/* Social Links */}
          <div className="flex space-x-6">
            {socialLinks.map((social, index) => (
              <a
                key={index}
                href={social.url}
                target="_blank"
                rel="noopener noreferrer"
                className="p-3 glass-card hover:bg-cosmic-primary/20 smooth-transition hover:scale-110"
                title={social.label}
              >
                <social.icon className="h-5 w-5" />
              </a>
            ))}
          </div>
          
          {/* Copyright */}
          <div className="text-center">
            <p className="text-muted-foreground flex items-center justify-center gap-1">
              © {currentYear} 
              {/* TODO: Replace with your name */}
              <span className="text-cosmic-primary font-medium">Your Name</span>. 
              Made with <Heart className="h-4 w-4 text-red-500 mx-1" /> using React & TailwindCSS.
            </p>
          </div>
          
          {/* GitHub Pages Note */}
          <div className="text-center">
            <p className="text-xs text-muted-foreground">
              Hosted on GitHub Pages • Built with Lovable
            </p>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;