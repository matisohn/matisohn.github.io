import { Button } from "@/components/ui/button";
import { ArrowDown, Github, Linkedin, Mail } from "lucide-react";
import cosmicBg from "@/assets/cosmic-bg.png";

const Hero = () => {
  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden">
      {/* Background Image */}
      <div 
        className="absolute inset-0 bg-cover bg-center bg-no-repeat"
        style={{ backgroundImage: `url(${cosmicBg})` }}
      />
      
      {/* Overlay */}
      <div className="absolute inset-0 bg-background/60 dark:bg-background/70" />
      
      {/* Content */}
      <div className="relative z-10 text-center max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="floating-animation">
          <h1 className="text-5xl sm:text-6xl lg:text-7xl font-bold mb-6">
            {/* TODO: Add your name here */}
            <span className="text-gradient"> Matisohn Huynh </span>
          </h1>
          <p className="text-xl sm:text-2xl lg:text-3xl text-muted-foreground mb-8 max-w-3xl mx-auto">
            {/* TODO: Add your title/description here */}
            Systems Engineering Technical Intern / Electrical Engineering Student at University of Miami
            <br />
            <span className="text-cosmic-primary">Looking to learn and grow!</span>
          </p>
        </div>
        
        {/* CTA Buttons */}
        <div className="flex flex-col sm:flex-row items-center justify-center gap-4 mb-12">
          <Button 
            size="lg" 
            className="cosmic-gradient text-white hover:scale-105 smooth-transition shadow-cosmic"
            asChild
          >
            <a href="#projects">View My Work</a>
          </Button>
          <Button 
            variant="outline" 
            size="lg" 
            className="glass-card hover:scale-105 smooth-transition"
            asChild
          >
            <a href="#contact">Get In Touch</a>
          </Button>
        </div>

        {/* Social Links */}
        <div className="flex items-center justify-center space-x-6 mb-12">
          {/* TODO: Add your social media links */}
          <a 
            href="https://github.com/matisohn" 
            target="_blank" 
            rel="noopener noreferrer"
            className="p-3 glass-card hover:bg-cosmic-primary/20 smooth-transition hover:scale-110"
          >
            <Github className="h-6 w-6" />
          </a>
          <a 
            href="https://www.linkedin.com/in/matisohn-huynh-41662228a" 
            target="_blank" 
            rel="noopener noreferrer"
            className="p-3 glass-card hover:bg-cosmic-primary/20 smooth-transition hover:scale-110"
          >
            <Linkedin className="h-6 w-6" />
          </a>
          <a 
            href="mailto:matihuynh@gmail.com"
            className="p-3 glass-card hover:bg-cosmic-primary/20 smooth-transition hover:scale-110"
          >
            <Mail className="h-6 w-6" />
          </a>
        </div>

        {/* Scroll Indicator */}
        <div className="animate-bounce">
          <a href="#about" className="inline-block p-2">
            <ArrowDown className="h-6 w-6 text-cosmic-primary" />
          </a>
        </div>
      </div>
    </section>
  );
};

export default Hero;
