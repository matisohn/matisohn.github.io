import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ExternalLink, Github } from "lucide-react";

const Projects = () => {
  const projects = [
    {
      title: "Project One",
      description: "A full-stack web application built with React and Node.js that helps users manage their daily tasks with an intuitive interface.",
      image: "/api/placeholder/600/400",
      technologies: ["React", "Node.js", "MongoDB", "TailwindCSS"],
      liveUrl: "https://project-one.com",
      githubUrl: "https://github.com/yourusername/project-one",
      featured: true
    },
    {
      title: "Project Two",
      description: "An e-commerce platform featuring real-time inventory management, payment processing, and responsive design.",
      image: "/api/placeholder/600/400",
      technologies: ["Next.js", "Stripe", "PostgreSQL", "Prisma"],
      liveUrl: "https://project-two.com",
      githubUrl: "https://github.com/yourusername/project-two",
      featured: true
    },
    {
      title: "Project Three",
      description: "A mobile-first progressive web app for fitness tracking with data visualization and social features.",
      image: "/api/placeholder/600/400",
      technologies: ["Vue.js", "PWA", "Chart.js", "Firebase"],
      liveUrl: "https://project-three.com",
      githubUrl: "https://github.com/yourusername/project-three",
      featured: false
    }
  ];

  return (
    <section id="projects" className="py-20 px-4 sm:px-6 lg:px-8 bg-muted/50">
      <div className="max-w-7xl mx-auto">
        {/* Section Header */}
        <div className="text-center mb-16">
          <h2 className="text-4xl sm:text-5xl font-bold mb-6">
            Featured <span className="text-gradient">Projects</span>
          </h2>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            {/* TODO: Add your projects description */}
            Here are some of my recent projects that showcase my skills in full-stack development, 
            UI/UX design, and problem-solving. Each project represents a unique challenge and learning experience.
          </p>
        </div>

        {/* Projects Grid */}
        <div className="grid gap-8">
          {projects.map((project, index) => (
            <Card 
              key={index} 
              className={`glass-card hover:shadow-cosmic smooth-transition overflow-hidden ${
                project.featured ? 'lg:flex lg:items-center' : ''
              }`}
            >
              {project.featured ? (
                // Featured Project Layout
                <>
                  <div className="lg:w-1/2">
                    <img 
                      src={project.image} 
                      alt={project.title}
                      className="w-full h-64 lg:h-full object-cover"
                    />
                  </div>
                  <div className="lg:w-1/2 p-8">
                    <CardHeader className="p-0 mb-6">
                      <CardTitle className="text-2xl mb-2">{project.title}</CardTitle>
                      <CardDescription className="text-base">{project.description}</CardDescription>
                    </CardHeader>
                    
                    <CardContent className="p-0">
                      <div className="flex flex-wrap gap-2 mb-6">
                        {project.technologies.map((tech) => (
                          <Badge key={tech} variant="outline" className="cosmic-gradient text-white">
                            {tech}
                          </Badge>
                        ))}
                      </div>
                      
                      <div className="flex space-x-4">
                        <Button 
                          asChild 
                          className="cosmic-gradient text-white hover:scale-105 smooth-transition"
                        >
                          <a href={project.liveUrl} target="_blank" rel="noopener noreferrer">
                            <ExternalLink className="h-4 w-4 mr-2" />
                            Live Demo
                          </a>
                        </Button>
                        <Button variant="outline" asChild className="hover:scale-105 smooth-transition">
                          <a href={project.githubUrl} target="_blank" rel="noopener noreferrer">
                            <Github className="h-4 w-4 mr-2" />
                            Code
                          </a>
                        </Button>
                      </div>
                    </CardContent>
                  </div>
                </>
              ) : (
                // Regular Project Layout
                <>
                  <img 
                    src={project.image} 
                    alt={project.title}
                    className="w-full h-48 object-cover"
                  />
                  <CardHeader>
                    <CardTitle>{project.title}</CardTitle>
                    <CardDescription>{project.description}</CardDescription>
                  </CardHeader>
                  
                  <CardContent>
                    <div className="flex flex-wrap gap-2 mb-4">
                      {project.technologies.map((tech) => (
                        <Badge key={tech} variant="outline">
                          {tech}
                        </Badge>
                      ))}
                    </div>
                    
                    <div className="flex space-x-4">
                      <Button size="sm" asChild className="cosmic-gradient text-white">
                        <a href={project.liveUrl} target="_blank" rel="noopener noreferrer">
                          <ExternalLink className="h-4 w-4 mr-2" />
                          Demo
                        </a>
                      </Button>
                      <Button size="sm" variant="outline" asChild>
                        <a href={project.githubUrl} target="_blank" rel="noopener noreferrer">
                          <Github className="h-4 w-4 mr-2" />
                          Code
                        </a>
                      </Button>
                    </div>
                  </CardContent>
                </>
              )}
            </Card>
          ))}
        </div>

        {/* View More Button */}
        <div className="text-center mt-12">
          <Button 
            variant="outline" 
            size="lg" 
            className="hover:scale-105 smooth-transition"
            asChild
          >
            <a href="https://github.com/yourusername" target="_blank" rel="noopener noreferrer">
              View All Projects on GitHub
            </a>
          </Button>
        </div>
      </div>
    </section>
  );
};

export default Projects;