import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Download, Eye, GraduationCap, Award, BookOpen } from "lucide-react";

const Resume = () => {
  const education = [
    {
      degree: "Bachelor of Science in Electrical Engineering",
      school: "University of Miami",
      period: "2024 - 2026",
      details: "Relevant coursework: Electronics, Logic Design, Digital Structures"
    }
  ];

  const certifications = [
    "AWS Certified Developer - Associate",
    "Google Cloud Professional Developer",
    "Meta Frontend Developer Certificate"
  ];

  const achievements = [
    "Led team of 5 developers on enterprise-level project",
    "Reduced application load time by 60% through optimization",
    "Implemented CI/CD pipeline reducing deployment time by 75%",
    "Mentored 10+ junior developers throughout career"
  ];

  return (
    <section id="resume" className="py-20 px-4 sm:px-6 lg:px-8 bg-muted/50">
      <div className="max-w-6xl mx-auto">
        {/* Section Header */}
        <div className="text-center mb-16">
          <h2 className="text-4xl sm:text-5xl font-bold mb-6">
            <span className="text-gradient">Resume</span>
          </h2>
          <p className="text-xl text-muted-foreground mb-8">
            Download my complete resume or view key highlights below.
          </p>
          
          {/* Resume Actions */}
          <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
            <Button 
              size="lg" 
              className="cosmic-gradient text-white hover:scale-105 smooth-transition shadow-cosmic"
              asChild
            >
              <a 
                href="/path-to-your-resume.pdf" 
                download="YourName-Resume.pdf"
                target="_blank" 
                rel="noopener noreferrer"
              >
                <Download className="h-5 w-5 mr-2" />
                Download PDF
              </a>
            </Button>
            <Button 
              variant="outline" 
              size="lg" 
              className="hover:scale-105 smooth-transition"
              asChild
            >
              <a 
                href="/path-to-your-resume.pdf" 
                target="_blank" 
                rel="noopener noreferrer"
              >
                <Eye className="h-5 w-5 mr-2" />
                View Online
              </a>
            </Button>
          </div>
          
          {/* TODO: Add your resume file to the public folder and update the paths above */}
          <p className="text-sm text-muted-foreground mt-4">
            💡 <strong>Note:</strong> Add your resume PDF file to the public folder and update the download/view links above.
          </p>
        </div>

        {/* Resume Highlights Grid */}
        <div className="grid lg:grid-cols-3 gap-8">
          {/* Education */}
          <Card className="glass-card hover:shadow-cosmic smooth-transition">
            <CardHeader>
              <div className="flex items-center space-x-3">
                <div className="cosmic-gradient p-2 rounded-lg">
                  <GraduationCap className="h-6 w-6 text-white" />
                </div>
                <CardTitle>Education</CardTitle>
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              {education.map((edu, index) => (
                <div key={index} className="space-y-2">
                  <h4 className="font-semibold">{edu.degree}</h4>
                  <p className="text-cosmic-primary font-medium">{edu.school}</p>
                  <p className="text-sm text-muted-foreground">{edu.period}</p>
                  <p className="text-sm text-muted-foreground">{edu.details}</p>
                </div>
              ))}
              
              {/* TODO: Add your education details */}
              <div className="mt-6 p-4 bg-muted/50 rounded-lg">
                <p className="text-sm text-muted-foreground">
                  💡 <strong>Update:</strong> Replace with your actual education details above.
                </p>
              </div>
            </CardContent>
          </Card>

          {/* Certifications */}
          <Card className="glass-card hover:shadow-cosmic smooth-transition">
            <CardHeader>
              <div className="flex items-center space-x-3">
                <div className="cosmic-gradient p-2 rounded-lg">
                  <Award className="h-6 w-6 text-white" />
                </div>
                <CardTitle>Certifications</CardTitle>
              </div>
            </CardHeader>
            <CardContent>
              <ul className="space-y-3">
                {certifications.map((cert, index) => (
                  <li key={index} className="flex items-start">
                    <span className="text-cosmic-primary mr-2">•</span>
                    <span className="text-sm">{cert}</span>
                  </li>
                ))}
              </ul>
              
              {/* TODO: Add your certifications */}
              <div className="mt-6 p-4 bg-muted/50 rounded-lg">
                <p className="text-sm text-muted-foreground">
                  💡 <strong>Update:</strong> Replace with your actual certifications above.
                </p>
              </div>
            </CardContent>
          </Card>

          {/* Key Achievements */}
          <Card className="glass-card hover:shadow-cosmic smooth-transition">
            <CardHeader>
              <div className="flex items-center space-x-3">
                <div className="cosmic-gradient p-2 rounded-lg">
                  <BookOpen className="h-6 w-6 text-white" />
                </div>
                <CardTitle>Key Achievements</CardTitle>
              </div>
            </CardHeader>
            <CardContent>
              <ul className="space-y-3">
                {achievements.map((achievement, index) => (
                  <li key={index} className="flex items-start">
                    <span className="text-cosmic-primary mr-2">•</span>
                    <span className="text-sm">{achievement}</span>
                  </li>
                ))}
              </ul>
              
              {/* TODO: Add your achievements */}
              <div className="mt-6 p-4 bg-muted/50 rounded-lg">
                <p className="text-sm text-muted-foreground">
                  💡 <strong>Update:</strong> Replace with your actual achievements above.
                </p>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </section>
  );
};

export default Resume;
