import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Code, Palette, Rocket } from "lucide-react";

const About = () => {
  const skills = [
    "JavaScript", "C++", "Groovy", "Cameo", "Python"
  ];

  const features = [
    {
      icon: Code,
      title: "Full-Stack Development",
      description: "Building scalable web applications with modern technologies and best practices."
    },
    {
      icon: Palette,
      title: "UI/UX Design",
      description: "Creating intuitive and beautiful user interfaces that provide exceptional user experiences."
    },
    {
      icon: Rocket,
      title: "Performance Optimization",
      description: "Ensuring fast, responsive, and efficient applications that users love."
    }
  ];

  return (
    <section id="about" className="py-20 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto">
        {/* Section Header */}
        <div className="text-center mb-16">
          <h2 className="text-4xl sm:text-5xl font-bold mb-6">
            About <span className="text-gradient">Me</span>
          </h2>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            {/* TODO: Add your personal description here */}
            Intrested in the intersection of deep learning and systems engineering.
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-12 items-center">
          {/* About Text */}
          <div className="space-y-6">
            <div className="glass-card rounded-xl p-8">
              <h3 className="text-2xl font-bold mb-4">My Journey</h3>
              <p className="text-muted-foreground mb-6 leading-relaxed">
                {/* TODO: Add your story/background here */}
                With over X years of experience in web development, I've worked with startups and 
                established companies to create digital experiences that users love. My journey started 
                with curiosity about how websites work, and it has evolved into a passion for crafting 
                elegant solutions to complex problems.
              </p>
              <p className="text-muted-foreground leading-relaxed">
                {/* TODO: Add more about your approach/philosophy */}
                I believe in writing clean, maintainable code and staying up-to-date with the latest 
                technologies and best practices. When I'm not coding, you can find me exploring new 
                design trends, contributing to open source projects, or sharing knowledge with the developer community.
              </p>
            </div>

            {/* Skills */}
            <div className="glass-card rounded-xl p-8">
              <h3 className="text-2xl font-bold mb-6">Skills & Technologies</h3>
              <div className="flex flex-wrap gap-2">
                {skills.map((skill) => (
                  <Badge 
                    key={skill} 
                    variant="secondary" 
                    className="cosmic-gradient text-white hover:scale-105 smooth-transition"
                  >
                    {skill}
                  </Badge>
                ))}
              </div>
            </div>
          </div>

          {/* Features Grid */}
          <div className="space-y-6">
            {features.map((feature, index) => (
              <Card key={index} className="glass-card hover:shadow-cosmic smooth-transition">
                <CardContent className="p-6">
                  <div className="flex items-start space-x-4">
                    <div className="cosmic-gradient p-3 rounded-lg">
                      <feature.icon className="h-6 w-6 text-white" />
                    </div>
                    <div>
                      <h4 className="text-xl font-semibold mb-2">{feature.title}</h4>
                      <p className="text-muted-foreground">{feature.description}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default About;
